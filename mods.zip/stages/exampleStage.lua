function onCreate()
makeLuaSprite('theGround', 'ground', -600, -1500)
addLuaSprite('theGround', false)
setLuaSpriteScrollFactor('theGround', 1, 1);

close(true)
	end


function onBeatHit(...)

	end

function onStepHit(...)
	-- body
end

function onUpdate( ... )
	-- body
end